const hdkey = require('ethereumjs-wallet/hdkey');

var publicKeyString = process.argv[2];
var index = process.argv[3];

console.log(JSON.stringify(DeriveAddress(publicKeyString, index)));

function DeriveAddress(pubextkey, index){
    var hd = hdkey.fromExtendedKey(pubextkey);
    var child = hd.deriveChild(index);
    var wallet = child.getWallet();
    return {
        index: child._hdkey.index,
        address: "0x" + wallet.getAddress().toString("hex")
    };
}
